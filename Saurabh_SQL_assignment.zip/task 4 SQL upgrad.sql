use assignment;
DELIMITER $$

CREATE FUNCTION bajaj_signal(trade_date Date)
RETURNS VARCHAR(10) DETERMINISTIC
BEGIN
	DECLARE trade_signal VARCHAR(10);
    SELECT `Signal` 
    FROM bajaj2 
    WHERE Date = trade_date 
    INTO trade_signal; 
	RETURN trade_signal;
END $$

DELIMITER ;