use assignment;

-- creating master table
 create table master_stock_info
 select tcs.`Date`,b.`Close price` as 'Bajaj',
 tcs.`Close price` as 'TCS' ,tvs.`Close price` as 'TVS',
 i.`Close price` as 'Infosys',e.`Close price` as 'Eicher',
 h.`Close price` as 'Hero'
 from tcs  inner join eicher_motors e on e.`Date`=tcs.`Date`
 inner join  tvs_motors tvs on tvs.`Date`= tcs.`Date`
 inner join  hero_motocorp h on h.`Date` = tcs.`Date`
 inner join  bajaj_auto b on b.`Date`=tcs.`Date`
 inner join  infosys i on i.`Date`=tcs.`Date` order by tcs.`Date`;