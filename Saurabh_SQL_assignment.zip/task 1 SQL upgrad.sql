use Assignment;

-- for  Creating bajaj1 

CREATE TABLE bajaj1 AS
SELECT Date, ROUND(`Close Price`,2) as `Close Price`, 
ROUND(AVG(`Close Price`) OVER(ORDER BY `Date` ROWS 19 PRECEDING),2) AS `20 Day MA`,
ROUND(AVG(`Close Price`) OVER(ORDER BY `Date` ROWS 49 PRECEDING),2) AS `50 Day MA`
FROM bajaj_auto;

-- for Creating eicher1 

CREATE TABLE eicher1 AS
SELECT Date, ROUND(`Close Price`,2) as `Close Price`, 
ROUND(AVG(`Close Price`) OVER(ORDER BY `Date` ROWS 19 PRECEDING),2) AS `20 Day MA`,
ROUND(AVG(`Close Price`) OVER(ORDER BY `Date` ROWS 49 PRECEDING),2) AS `50 Day MA`
FROM eicher_motors;

-- for Creating hero1 

CREATE TABLE hero1 AS
SELECT Date, ROUND(`Close Price`,2) as `Close Price`, 
ROUND(AVG(`Close Price`) OVER(ORDER BY `Date` ROWS 19 PRECEDING),2) AS `20 Day MA`,
ROUND(AVG(`Close Price`) OVER(ORDER BY `Date` ROWS 49 PRECEDING),2) AS `50 Day MA`
FROM hero_motocorp;

-- for Creating infosys1 

CREATE TABLE infosys1 AS
SELECT Date, ROUND(`Close Price`,2) as `Close Price`, 
ROUND(AVG(`Close Price`) OVER(ORDER BY `Date` ROWS 19 PRECEDING),2) AS `20 Day MA`,
ROUND(AVG(`Close Price`) OVER(ORDER BY `Date` ROWS 49 PRECEDING),2) AS `50 Day MA`
FROM infosys;

-- for Creating tcs1 

CREATE TABLE tcs1 AS
SELECT Date, ROUND(`Close Price`,2) as `Close Price`, 
ROUND(AVG(`Close Price`) OVER(ORDER BY `Date` ROWS 19 PRECEDING),2) AS `20 Day MA`,
ROUND(AVG(`Close Price`) OVER(ORDER BY `Date` ROWS 49 PRECEDING),2) AS `50 Day MA`
FROM tcs;

-- for Creating tvs1 

CREATE TABLE tvs1 AS
SELECT Date, ROUND(`Close Price`,2) as `Close Price`, 
ROUND(AVG(`Close Price`) OVER(ORDER BY `Date` ROWS 19 PRECEDING),2) AS `20 Day MA`,
ROUND(AVG(`Close Price`) OVER(ORDER BY `Date` ROWS 49 PRECEDING),2) AS `50 Day MA`
FROM tvs_motors;