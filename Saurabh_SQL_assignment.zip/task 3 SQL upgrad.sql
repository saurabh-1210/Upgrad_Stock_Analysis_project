use assignment;

 -- create table bajaj2
create table bajaj2
 select `Date`,`Close price`,
 case 
 when `50 Day MA` is NULL then 'NA'
 when `20 Day MA`>`50 Day MA` and ((lag(`20 Day MA`,1) over(order by `Date`))<(lag(`50 Day MA`,1) over(order by `Date`))) then 'BUY'
 when `20 Day MA`<`50 Day MA` and ((lag(`20 Day MA`,1) over(order by `Date`))>(lag(`50 Day MA`,1) over(order by `Date`))) then 'SELL'
 else 'HOLD' 
 end as `Signal`
 from bajaj1 ;
 
 -- create table eicher2 
 create table eicher2
 select `Date`,`Close price`,
 case 
 when `50 Day MA` is NULL then 'NA'
 when `20 Day MA`>`50 Day MA` and ((lag(`20 Day MA`,1) over(order by `Date`))<(lag(`50 Day MA`,1) over(order by `Date`))) then 'BUY'
 when `20 Day MA`<`50 Day MA` and ((lag(`20 Day MA`,1) over(order by `Date`))>(lag(`50 Day MA`,1) over(order by `Date`))) then 'SELL'
 else 'HOLD' 
 end as `Signal`
 from eicher1;
 
 -- create table tcs2
 create table tcs2
 select `Date`,`Close price`,
 case 
 when `50 Day MA` is NULL then 'NA'
 when `20 Day MA`>`50 Day MA` and ((lag(`20 Day MA`,1) over(order by `Date`))<(lag(`50 Day MA`,1) over(order by `Date`))) then 'BUY'
 when `20 Day MA`<`50 Day MA` and ((lag(`20 Day MA`,1) over(order by `Date`))>(lag(`50 Day MA`,1) over(order by `Date`))) then 'SELL'
 else 'HOLD' 
 end as `Signal`
 from tcs1 ;
 
 -- create table tvs2
 create table tvs2
 select `Date`,`Close price`,
 case 
 when `50 Day MA` is NULL then 'NA'
 when `20 Day MA`>`50 Day MA` and ((lag(`20 Day MA`,1) over(order by `Date`))<(lag(`50 Day MA`,1) over(order by `Date`))) then 'BUY'
 when `20 Day MA`<`50 Day MA` and ((lag(`20 Day MA`,1) over(order by `Date`))>(lag(`50 Day MA`,1) over(order by `Date`))) then 'SELL'
 else 'HOLD' 
 end as `Signal`
 from tvs1 ;
 
 -- create table hero2
 create table hero2
 select `Date`,`Close price`,
 case 
 when `50 Day MA` is NULL then 'NA'
 when `20 Day MA`>`50 Day MA` and ((lag(`20 Day MA`,1) over(order by `Date`))<(lag(`50 Day MA`,1) over(order by `Date`))) then 'BUY'
 when `20 Day MA`<`50 Day MA` and ((lag(`20 Day MA`,1) over(order by `Date`))>(lag(`50 Day MA`,1) over(order by `Date`))) then 'SELL'
 else 'HOLD' 
 end as `Signal`
 from hero1 ;
 
 -- create  table infosys2
 create table infosys2
 select `Date`,`Close price`,
 case 
 when `50 Day MA` is NULL then 'NA'
 when `20 Day MA`>`50 Day MA` and ((lag(`20 Day MA`,1) over(order by `Date`))<(lag(`50 Day MA`,1) over(order by `Date`))) then 'BUY'
 when `20 Day MA`<`50 Day MA` and ((lag(`20 Day MA`,1) over(order by `Date`))>(lag(`50 Day MA`,1) over(order by `Date`))) then 'SELL'
 else 'HOLD' 
 end as `Signal`
 from infosys1 ;